import os
import re
import numpy as np
import math
from strsimpy.levenshtein import Levenshtein

recv_data = []
tr = []
def fileRead():
    for idx in range(220,430,10):
        data=[]
        rate=[]
        path = "./data/"+str(idx)+"receiver.log"
        if(not os.path.isfile(path)):
            print("file not found")
            return
        with open(path,'r') as fr:
            lines=fr.readlines()             
        for i in range(len(lines)):
            if lines[i].strip() == "recv=":
                next_line = lines[i+1].strip()
                if next_line[:31] == "1 1 0 0 0 0 1 1 1 0 0 1 1 1 0 0":
                    data.append(next_line)
                    tr_line = lines[i+3].strip()
                    rate.append(tr_line)
        recv_data.append(data)
        tr.append(rate)
    #print(recv_data)
    return

def get_error_rate():

    correct_str='1 1 0 0 0 0 1 1 1 0 0 1 1 1 0 0 0 1 1 0 1 0 0 0 0 1 1 0 0 1 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 1 0 0 0 1 1 0 1 1 1 1 0 1 1 1 0 1 1 1 0 1 1 0 1 1 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 1 0 0 0 1 1 0 0 0 0 1 0 1 1 0 0 0 1 0 0 1 1 0 0 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 1 1'
    levenshtein = Levenshtein()
    
    
    slot = list(range(220,430,10))
    print("slot = ")
    print(slot)
    s = 0
    error_rate = []
    standard_deviation = []
    standard_error = []
    transmission_rate = []
    for tdata in recv_data:
        error_num = []
        for data in tdata:
            nb = levenshtein.distance(correct_str, data)
            if(nb<=50.0):
                error_num.append(nb)   # 每组数据的错误比特数
        #print("slot = %d" % slot)
        #print(error_num)
        num = sum(error_num);
        error_rate.append(num/(128*len(error_num)))
        #print("error_rate = %f" % error_rate)
        avg_error = num/len(error_num)  # 所有数据的平均错误比特数
        error_squared_sum = sum((i - avg_error) ** 2 for i in error_num)  # 计算每组数据的错误比特数与平均错误比特数之差的平方和
        sdeviation = math.sqrt(error_squared_sum / len(error_num))  # 计算标准偏差
        standard_deviation.append(sdeviation)   
        #print("standard_deviation = %f" % standard_deviation)
        serror = sdeviation / math.sqrt(len(error_num))  # 计算标准误差
        standard_error.append(serror)   
        
        rate = sum(list(map(float, tr[s])))/len(tr[s])
        transmission_rate.append(rate)
        #print("transmission_rate = %f" % rate)
        #print("")
        s += 1
        
    print("error_rate = ")
    print(error_rate)
    print("transmission_rate = ")
    print(transmission_rate)
    print("standard_deviation = ")
    print(standard_deviation)
    print("standard_error = ")
    print(standard_error)

if __name__=="__main__":
       
    #text=get_error_rate(args.file_path,int(args.Threshold))
    fileRead()
    get_error_rate()
            
